package com.example.backstore

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
