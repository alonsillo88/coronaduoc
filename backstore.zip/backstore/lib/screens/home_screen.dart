import 'package:flutter/material.dart';
import '../utils/custom_colors.dart';
import '../widgets/custom_drawer.dart';  // Importa el menú reutilizable

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar( 
        title: const Text(
          'CORONA', 
          style: TextStyle(color: CustomColors.black),  // Texto negro
        ),
        elevation: 0,  // Sin sombra en el AppBar
        leading: Builder(
          builder: (BuildContext context) {
            return IconButton(
              icon: const Icon(Icons.menu, color: CustomColors.black),  // Icono de menú negro
              onPressed: () {
                Scaffold.of(context).openDrawer();  // Abre el Drawer
              },
            );
          },
        ),
      ),
      drawer: const CustomDrawer(),  // Reutiliza el menú lateral
      body: Padding(
        padding: const EdgeInsets.all(20.0),  // Espaciado alrededor del contenido
        child: _buildBody(),
      ),
    );
  }

  Widget _buildBody() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,  // Centra los elementos verticalmente
      crossAxisAlignment: CrossAxisAlignment.stretch,  // Hace que los botones ocupen todo el ancho
      children: [
        _buildButton('SINCRONIZAR', () {
          // Acción para el botón "SINCRONIZAR"
        }),
        const SizedBox(height: 20),  // Espaciado entre botones
        _buildButton('PICKING ASIGNADO', () {
          // Acción para el botón "PICKING ASIGNADO"
        }),
        const SizedBox(height: 20),
        _buildButton('CONSOLIDADO RECOLECCIÓN', () {
          // Acción para el botón "CONSOLIDADO RECOLECCIÓN"
        }),
        const SizedBox(height: 20),
        _buildButton('CONSULTAR STOCK', () {
          // Acción para el botón "CONSULTAR STOCK"
        }),
      ],
    );
  }

  Widget _buildButton(String text, VoidCallback onPressed) {
    return ElevatedButton(
      onPressed: onPressed,
      style: ElevatedButton.styleFrom(
        backgroundColor: CustomColors.purple,  // Botones de color morado
        padding: const EdgeInsets.symmetric(vertical: 20),  // Tamaño del botón
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(30),  // Bordes redondeados
        ),
      ),
      child: Text(
        text,
        style: const TextStyle(color: CustomColors.white),  // Texto blanco
      ),
    );
  }
}
