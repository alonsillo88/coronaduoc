import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import '../utils/custom_colors.dart';
import 'login_screen.dart';

class LoadingScreen extends StatefulWidget {
  const LoadingScreen({super.key, this.logoWidth = 300});

  final double logoWidth;

  @override
  LoadingScreenState createState() => LoadingScreenState();
}

class LoadingScreenState extends State<LoadingScreen> with SingleTickerProviderStateMixin {
  double _progressValue = 0.0;
  late Timer _timer;
  late AnimationController _controller;
  late Animation<double> _animation;

  @override
  void initState() {
    super.initState();

    // Configurar la animación con duración de 1 segundo para la "O" giratoria
    _controller = AnimationController(
      duration: const Duration(seconds: 1), 
      vsync: this,
    )..repeat(); // Repetir la animación de forma continua

    // Usar una animación lineal de desplazamiento vertical (y)
    _animation = Tween<double>(begin: -50, end: -100).animate(_controller);

    _startLoading();
  }

  // Simulación de carga con una barra de progreso
  void _startLoading() {
    _timer = Timer.periodic(const Duration(milliseconds: 120), (Timer timer) {
      setState(() {
        _progressValue += 0.05;
        if (_progressValue >= 1.0) {
          _timer.cancel();
          _controller.stop();
          // Navegar al LoginScreen al completar la carga
          Navigator.of(context).pushReplacement(
            MaterialPageRoute(builder: (context) => const LoginScreen()),
          );
        }
      });
    });
  }

  @override
  void dispose() {
    _timer.cancel();
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: CustomColors.background,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(
              width: widget.logoWidth,
              height: widget.logoWidth * 0.3,
              child: FittedBox(
                fit: BoxFit.contain,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    SvgPicture.asset('assets/svg/c.svg', height: 50), // Letra C
                    const SizedBox(width: 10), // Padding entre las letras
                    SvgPicture.asset('assets/svg/o.svg', height: 50), // Primera O estática
                    const SizedBox(width: 10), // Padding entre las letras
                    SvgPicture.asset('assets/svg/r.svg', height: 50), // Letra R
                    const SizedBox(width: 10), // Padding entre las letras

                    // ClipRect para contener la animación de las "O"
                    ClipRect(
                      child: SizedBox(
                        height: 50,
                        width: 50,
                        child: Stack(
                          alignment: Alignment.center,
                          children: [
                            AnimatedBuilder(
                              animation: _animation,
                              builder: (context, child) {
                                return Transform.translate(
                                  offset: Offset(0, _animation.value), // Desplazar verticalmente
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: [
                                      SvgPicture.asset('assets/svg/o.svg', height: 50), // O superior
                                      SvgPicture.asset('assets/svg/o.svg', height: 50), // O media
                                      SvgPicture.asset('assets/svg/o.svg', height: 50), // O inferior
                                    ],
                                  ),
                                );
                              },
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(width: 10), // Padding entre las letras
                    SvgPicture.asset('assets/svg/n.svg', height: 50), // Letra N
                    const SizedBox(width: 10), // Padding entre las letras
                    SvgPicture.asset('assets/svg/a.svg', height: 50), // Letra A
                    Padding(
                      padding: const EdgeInsets.only(bottom: 0),
                      child: SvgPicture.asset('assets/svg/copyright.svg', height: 15), // Copyright
                    ),
                  ],
                ),
              ),
            ),
            const Text(
              'Backstore',
              style: TextStyle(
                fontSize: 15,
                color: CustomColors.black,
              )),
            const SizedBox(height: 10),

            // Barra de progreso
            SizedBox(
              width: MediaQuery.of(context).size.width * 0.7,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: LinearProgressIndicator(
                  value: _progressValue,
                  minHeight: 10,
                  color: CustomColors.purple,
                  backgroundColor: CustomColors.lightPurple,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
