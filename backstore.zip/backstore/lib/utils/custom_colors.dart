import 'package:flutter/material.dart';

class CustomColors {
  static const Color purple = Color(0xFF9B51E0);         // Morado
  static const Color mediumGray = Color(0xFF828282);     // Gris Medio
  static const Color lightGray = Color(0xFFBDBDBD);      // Gris Claro
  static const Color white = Color(0xFFFFFFFF);          // Blanco
  static const Color black = Color(0xFF000000);          // Negro
  static const Color background = Color(0xFFE0E0E0);     // Fondo 
  static const Color pantone2706C = Color(0xFFD5E8FE);   // Pantone 2706 C
  static const Color lightPurple = Color(0xFFE1C5F7);    // Morado Claro
  static const Color grayWithPurpleTone = Color(0xFFB0A6B0);  // Gris con tono morado
}

